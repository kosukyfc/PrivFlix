# Plano — Flex Media Platform

## Escopo
Resolver a visualização do Preview substituindo o conteúdo de exemplo por uma interface original de streaming inspirada na arquitetura pública observada no 1Flex: home editorial, catálogos, busca, minha lista e player. A implementação é clean-room: não reutiliza código proprietário, sessões, tokens ou mídia protegida.

## Abordagem de implementação
- React + TypeScript + Wouter já presentes no starter.
- Uma shell responsiva compartilhada com sidebar desktop, bottom navigation mobile, header de busca e conteúdo em tema escuro.
- Dados de catálogo locais para o primeiro Preview, com cards, filtros de gênero e estado de busca; os pontos de integração com API ficam isolados para conexão autorizada.
- API REST própria em `/api/catalog`, `/api/titles/:id` e `/api/titles/:id/playback`, com fontes `embed`, `mp4` e `hls` configuradas por ambiente e allowlist HTTPS.
- Player demonstrativo com fallback visual e reprodução real somente quando uma fonte licenciada for configurada; não extrai streams, tokens ou links ocultos.
- Rotas `/`, `/movies`, `/tv-shows`, `/games`, `/live-tv`, `/sports`, `/search`, `/my-list`, `/torrent` e `/play/:id`.
- `public/manus-routes.json` sincronizado com as rotas para o Preview.

## Decisões de design

### Estilos candidatos
1. **Streaming Noir Editorial** — 0,06: preto azulado, roxo elétrico, hero cinematográfico e navegação lateral.
2. **Neon Arcade** — 0,04: cores saturadas, cards com glow e tipografia display.
3. **Cinema Monochrome** — 0,08: cinza grafite, vermelho de ação e composição minimalista.

Escolhido: **Streaming Noir Editorial**.

- **Design Movement:** interfaces de streaming premium com direção de arte cinematográfica e contraste alto.
- **Core Principles:** hierarquia por imagem e espaço; navegação persistente; ações com feedback imediato; conteúdo legível em telas pequenas.
- **Color Philosophy:** fundo quase preto azulado para deixar o conteúdo visual dominar; violeta como cor proprietária de ação; cinza frio para informação secundária.
- **Layout Paradigm:** composição assimétrica com hero de largura total, trilhos horizontais de catálogo e sidebar fixa em desktop.
- **Signature Elements:** wordmark “FLEX” com corte diagonal, chips em vidro fosco e gradiente radial violeta no hero.
- **Interaction Philosophy:** explorar primeiro, agir depois; hover revela contexto e CTA; filtros permanecem visíveis e não escondem o catálogo.
- **Animation:** transições de 180–260ms, cards elevam 4px, hero usa entrada suave; respeitar `prefers-reduced-motion`.
- **Typography System:** Inter/system sans para leitura; pesos 500/700/800; títulos compactos e labels em caixa alta com tracking positivo.
- **Brand Essence:** uma sala de descoberta para quem quer escolher algo bom rápido — editorial, calorosa, direta.
- **Brand Voice:** “Sua próxima sessão começa aqui.” / “Escolha um título e aperte play.”
- **Wordmark & Logo:** “FLEX” em caixa alta com o X formado por duas lâminas diagonais.
- **Signature Brand Color:** `#9B6CFF`, violeta elétrico usado somente em ações e estados ativos.

## Estrutura
- `client/src/App.tsx`: providers e tabela de rotas.
- `client/src/pages/Home.tsx`: shell, home, catálogos, busca, lista e player demonstrativo.
- `server/mediaCatalog.ts`: registro local de títulos e validação de URLs de playback autorizadas.
- `.env.example`: configuração de origens permitidas e fontes por título sem gravar tokens no Git.
- `client/src/index.css`: tokens, responsividade, componentes visuais e acessibilidade.
- `client/public/manus-routes.json`: manifesto de páginas para o Preview.
- `app.config.ts`: metadado de logo do projeto quando a versão for checkpointada.

## Build e Preview
- Executar `pnpm check` e `pnpm build`.
- Servir com `pnpm dev` na porta configurada 3000.
- Validar `/`, `/movies`, `/search` e `/play/:id` via screenshot do Webdev.
