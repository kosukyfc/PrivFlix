# Flex Media Platform — Guia completo

## 1. Visão geral

O projeto é uma interface de streaming em React + TypeScript, servida por Express, com uma API própria para registrar títulos e fontes de reprodução autorizadas.

A implementação suporta:

- home editorial de streaming;
- catálogo de filmes, séries, jogos, TV ao vivo e esportes;
- busca e minha lista;
- player visual com fallback demonstrativo;
- player incorporado por iframe autorizado;
- reprodução de MP4 próprio;
- reprodução de HLS/M3U8 próprio;
- seleção entre várias fontes cadastradas;
- API REST de catálogo e playback;
- allowlist de origens HTTPS;
- execução local no Termux;
- build para produção via Vite + Express.

O projeto não extrai manifests ocultos, não contorna WAF/geobloqueio, não falsifica headers e não redistribui fontes de terceiros. As URLs devem ser fornecidas por uma API oficial, painel administrativo, CDN, S3 ou storage que você controle ou esteja autorizado a usar.

## 2. Estrutura de pastas

```text
flexclone/
├── client/
│   ├── public/
│   │   ├── flex-mark.svg
│   │   └── manus-routes.json
│   ├── src/
│   │   ├── pages/Home.tsx       # Home, catálogos, busca e player
│   │   ├── App.tsx              # Rotas do frontend
│   │   └── index.css             # Tema, responsividade e player
│   └── index.html
├── server/
│   ├── _core/
│   │   └── index.ts             # Bootstrap Express e endpoints REST
│   └── mediaCatalog.ts           # Registro e validação de playback
├── drizzle/
│   └── schema.ts                 # Schema MySQL do projeto
├── tools/
│   └── cde_authorized_backend.py # Referência Flask segura para Termux
├── .env.example                  # Configuração de fontes autorizadas
├── app.config.ts                 # Logo do projeto
├── package.json
├── pnpm-lock.yaml
├── plan.md
├── TODO.md
└── PROJECT_GUIDE.md
```

## 3. Requisitos

### Desenvolvimento Webdev/Node

- Node.js 20 ou superior;
- pnpm 10;
- navegador moderno;
- acesso às dependências npm.

### Termux

```bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git python
npm install -g pnpm
```

## 4. Instalação no Termux

Depois de extrair o ZIP:

```bash
cd flexclone
pnpm install
cp .env.example .env
```

Edite as configurações:

```bash
nano .env
```

Não coloque tokens temporários, senhas ou chaves privadas no Git ou no frontend.

## 5. Configuração de fontes autorizadas

O projeto lê as fontes a partir de variáveis de ambiente. O título de teste padrão é `969681`.

### Embed autorizado

```env
MEDIA_ALLOWED_ORIGINS=https://www.1flex.org
MEDIA_TITLE_969681=Título autorizado 969681
MEDIA_PLAYER_URL_969681=https://www.1flex.org/embed/969681
MEDIA_PLAYER_QUALITY_969681=Original
MEDIA_PLAYER_LANGUAGE_969681=pt-BR
```

A página precisa permitir incorporação por iframe. O projeto não remove `Content-Security-Policy`, `X-Frame-Options`, anúncios ou redirecionamentos da página original.

### MP4 próprio ou CDN autorizado

```env
MEDIA_ALLOWED_ORIGINS=https://cdn.seudominio.com
MEDIA_TITLE_969681=Meu filme licenciado
MEDIA_MP4_URL_969681=https://cdn.seudominio.com/videos/969681.mp4
MEDIA_MP4_QUALITY_969681=1080p
MEDIA_MP4_LANGUAGE_969681=pt-BR
```

O CDN deve permitir requisições `Range` para seek e playback eficiente.

### HLS/M3U8 próprio

```env
MEDIA_ALLOWED_ORIGINS=https://cdn.seudominio.com
MEDIA_HLS_URL_969681=https://cdn.seudominio.com/videos/969681/master.m3u8
MEDIA_HLS_QUALITY_969681=Adaptive
MEDIA_HLS_LANGUAGE_969681=pt-BR
```

Para HLS, o servidor deve configurar CORS e disponibilizar corretamente os segmentos referenciados pelo manifest.

### S3, Cloudflare R2 ou outro storage

Inclua a origem do bucket/CDN na allowlist:

```env
MEDIA_ALLOWED_ORIGINS=https://bucket.s3.amazonaws.com,https://cdn.seudominio.com
MEDIA_MP4_URL_969681=https://cdn.seudominio.com/videos/969681.mp4
```

Em produção, prefira uma URL assinada com expiração curta gerada pelo backend. Não gere a URL assinada no navegador.

## 6. Rodar no Termux

### Modo desenvolvimento

```bash
cd flexclone
pnpm dev
```

Abra:

```text
http://127.0.0.1:3000
```

Se precisar abrir pelo Android:

```bash
termux-open-url http://127.0.0.1:3000
```

### Modo produção local

```bash
pnpm build
pnpm start
```

### Diagnóstico de processo e porta

```bash
ss -ltnp | grep 3000
ps -A | grep -E 'node|tsx|vite'
```

Para parar um processo em primeiro plano:

```text
CTRL+C
```

## 7. API REST

### Saúde

```http
GET /api/health
```

Resposta:

```json
{"status":"ok"}
```

### Catálogo

```http
GET /api/catalog
```

### Título

```http
GET /api/titles/969681
```

### Playback

```http
GET /api/titles/969681/playback
```

Sem fonte configurada:

```json
{
  "status": "not_configured",
  "title": "Título autorizado 969681",
  "titleId": "969681",
  "type": "movie",
  "sources": [],
  "message": "Nenhuma fonte autorizada foi configurada para este título."
}
```

Com fonte configurada:

```json
{
  "status": "success",
  "titleId": "969681",
  "type": "movie",
  "sources": [
    {
      "id": "969681-mp4",
      "name": "Arquivo MP4 autorizado",
      "kind": "mp4",
      "url": "https://cdn.seudominio.com/videos/969681.mp4",
      "quality": "1080p",
      "language": "pt-BR"
    }
  ]
}
```

## 8. Rotas frontend

```text
/                  Home
/movies             Filmes
/tv-shows           Séries
/games              Jogos
/live-tv            TV ao vivo
/sports             Esportes
/search             Busca
/my-list            Minha lista
/torrent            Área reservada
/play/:id           Player do título
/embed              Embed genérico autorizado
```

Para abrir o título registrado:

```text
/play/969681
```

A rota `/play/:id` chama a API de playback. Se uma fonte autorizada existir, mostra o player real. Caso contrário, mostra o player demonstrativo sem fingir que há vídeo disponível.

## 9. Build e validação

```bash
pnpm check
pnpm build
```

Os comandos devem concluir sem erro. O aviso sobre `/api/platform/config.js` ser um script sem `type="module"` é emitido pelo Vite do starter e não impede o build.

## 10. Player e fontes

O frontend diferencia:

- `embed`: usa iframe sandbox;
- `mp4`: usa `<video controls>`;
- `hls`: usa `<video>` quando o navegador suporta HLS nativamente;
- `dash`: fica registrado no contrato da API e pode ser conectado a um player DASH autorizado.

A seleção de fontes aparece quando o endpoint retorna mais de uma fonte ativa.

## 11. Content Discovery Engine seguro

Para produção, a ingestão deve seguir este fluxo:

```text
Upload / API oficial / S3 / painel administrativo
                    ↓
Registro da origem e do operador
                    ↓
Extração de metadados do conteúdo próprio
                    ↓
Normalização de título, temporada e episódio
                    ↓
Correspondência com catálogo
                    ↓
Revisão manual se a confiança for baixa
                    ↓
Fonte autorizada ativa no playback
```

Pode-se usar `ffprobe` apenas em arquivos que você controla:

```bash
pkg install -y ffmpeg
ffprobe -v quiet -print_format json -show_format -show_streams arquivo.mp4
```

Metadados úteis:

- duração;
- codec;
- resolução;
- idioma;
- tags;
- nome do arquivo;
- container;
- bitrate.

## 12. Segurança

- Use autenticação administrativa para cadastrar fontes.
- Não exponha o endpoint de cadastro anonimamente em produção.
- Use allowlist de domínios.
- Aceite somente HTTPS.
- Não salve tokens temporários no repositório.
- Gere URLs assinadas no backend.
- Defina expiração curta para URLs privadas.
- Não transforme o backend em proxy aberto.
- Não siga redirects arbitrários.
- Registre auditoria de quem publicou cada fonte.
- Valide CORS e `Range` no CDN próprio.

## 13. Flask de referência

O arquivo `tools/cde_authorized_backend.py` contém uma implementação independente em Flask para Termux. Ele normaliza fontes fornecidas pelo operador, valida protocolos e expõe uma API equivalente.

Para usar:

```bash
python -m venv .venv
source .venv/bin/activate
pip install flask flask-cors
python tools/cde_authorized_backend.py
```

Teste:

```bash
curl http://127.0.0.1:5000/api/v1/health
```

## 14. Limitações conhecidas

- O catálogo atual possui dados demonstrativos e um registro autorizado de teste.
- O banco de dados ainda não foi conectado ao registro de playback; por enquanto, as configurações vêm do ambiente.
- O player DASH precisa de uma biblioteca própria de reprodução quando houver fonte DASH autorizada.
- Uma página externa pode bloquear iframe por política de segurança.
- O sistema não extrai streams ocultos de terceiros e não contorna proteções externas.

## 15. Comandos rápidos

```bash
# instalar
pnpm install

# configurar
cp .env.example .env
nano .env

# desenvolver
pnpm dev

# verificar
pnpm check
pnpm build

# abrir
termux-open-url http://127.0.0.1:3000
```
