"""Content Discovery Engine — referência segura para fontes autorizadas.

Este serviço não faz scraping de manifests ocultos, não contorna WAF/geobloqueio,
não falsifica headers e não atua como proxy de mídia de terceiros. As fontes
precisam ser declaradas por um operador autorizado ou recebidas de uma API
oficial do provedor.
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import asdict, dataclass
from typing import Literal
from urllib.parse import urlparse

from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": os.getenv("CORS_ORIGINS", "*")}})

Protocol = Literal["hls", "dash", "mp4", "embed"]

ALLOWED_ORIGINS = {
    origin.strip().rstrip("/")
    for origin in os.getenv("MEDIA_ALLOWED_ORIGINS", "https://cdn.example.com").split(",")
    if origin.strip()
}

EXTENSION_PROTOCOLS: dict[str, Protocol] = {
    ".m3u8": "hls",
    ".mpd": "dash",
    ".mp4": "mp4",
}


@dataclass(frozen=True)
class Source:
    id: str
    title_id: str
    provider: str
    url: str
    protocol: Protocol
    quality: str | None = None
    language: str | None = None
    subtitles: tuple[str, ...] = ()
    is_active: bool = True

    def public_dict(self) -> dict:
        data = asdict(self)
        data["subtitles"] = list(self.subtitles)
        return data


# Em produção, substitua por MySQL/PostgreSQL/Redis. O registro abaixo existe
# somente para demonstrar o contrato e pode ser carregado via API oficial.
SOURCES: dict[str, list[Source]] = {}


def source_id(title_id: str, url: str) -> str:
    digest = hashlib.sha256(f"{title_id}:{url}".encode()).hexdigest()[:16]
    return f"src_{digest}"


def validate_authorized_url(raw_url: str, protocol: str | None = None) -> tuple[str, Protocol]:
    """Valida uma URL declarada contra HTTPS + allowlist.

    A função não acessa a URL, não segue redirects e não tenta descobrir
    caminhos alternativos. Isso evita transformar a API em um proxy aberto.
    """
    parsed = urlparse(raw_url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("A fonte precisa usar uma URL HTTPS absoluta.")

    origin = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    if origin not in ALLOWED_ORIGINS:
        raise ValueError("A origem da fonte não está na allowlist autorizada.")

    suffix = os.path.splitext(parsed.path.lower())[1]
    inferred: Protocol | None = EXTENSION_PROTOCOLS.get(suffix)
    selected = protocol or inferred
    if selected not in {"hls", "dash", "mp4", "embed"}:
        raise ValueError("Informe protocol como hls, dash, mp4 ou embed.")

    # Uma página embed não precisa ter extensão de vídeo. Para mídia direta,
    # exige-se uma extensão compatível ou uma URL explicitamente registrada.
    if selected in {"hls", "dash", "mp4"} and inferred and inferred != selected:
        raise ValueError("O protocolo informado não corresponde à extensão da URL.")

    return raw_url, selected  # type: ignore[return-value]


def normalize_source(payload: dict) -> Source:
    required = ("title_id", "provider", "url")
    missing = [field for field in required if not payload.get(field)]
    if missing:
        raise ValueError(f"Campos obrigatórios ausentes: {', '.join(missing)}")

    url, protocol = validate_authorized_url(str(payload["url"]), payload.get("protocol"))
    title_id = str(payload["title_id"]).strip()
    provider = str(payload["provider"]).strip()[:120]
    quality = str(payload["quality"]).strip()[:40] if payload.get("quality") else None
    language = str(payload["language"]).strip()[:20] if payload.get("language") else None
    subtitles = tuple(str(item)[:20] for item in payload.get("subtitles", [])[:20])

    return Source(
        id=source_id(title_id, url),
        title_id=title_id,
        provider=provider,
        url=url,
        protocol=protocol,
        quality=quality,
        language=language,
        subtitles=subtitles,
        is_active=bool(payload.get("is_active", True)),
    )


@app.get("/api/v1/health")
def health():
    return jsonify({"status": "ok", "service": "content-discovery-engine"})


@app.post("/api/v1/sources")
def create_source():
    """Registra uma fonte fornecida pelo operador autorizado.

    Em produção, proteja a rota com autenticação administrativa e persista em
    banco. Nunca aceite esta rota anonimamente.
    """
    payload = request.get_json(silent=True) or {}
    try:
        source = normalize_source(payload)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    current = SOURCES.setdefault(source.title_id, [])
    current[:] = [item for item in current if item.id != source.id]
    current.append(source)
    return jsonify({"status": "accepted", "source": source.public_dict()}), 201


@app.get("/api/v1/titles/<title_id>/playback")
def playback(title_id: str):
    sources = [source.public_dict() for source in SOURCES.get(title_id, []) if source.is_active]
    return jsonify({
        "title_id": title_id,
        "sources": sources,
        "count": len(sources),
        "status": "ready" if sources else "not_configured",
    })


@app.get("/api/v1/titles/<title_id>/playback/<source_id>")
def playback_source(title_id: str, source_id: str):
    for source in SOURCES.get(title_id, []):
        if source.id == source_id and source.is_active:
            return jsonify(source.public_dict())
    return jsonify({"error": "Fonte não encontrada"}), 404


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Rota não encontrada"}), 404


if __name__ == "__main__":
    # Termux: python cde_authorized_backend.py
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5000")), debug=False)
