import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CirclePlay,
  Clock3,
  Compass,
  Film,
  Gamepad2,
  Heart,
  Home as HomeIcon,
  List,
  Maximize2,
  Menu,
  MessageCircle,
  MonitorPlay,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  Sparkles,
  Star,
  Tv,
  Volume2,
  VolumeX,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";

type Media = {
  id: string;
  title: string;
  year: string;
  genre: string;
  rating: string;
  duration: string;
  type: "movie" | "series" | "live" | "game";
  image: string;
  backdrop: string;
  description: string;
  accent: string;
  tag?: string;
};

type PlaybackSource = {
  id: string;
  name: string;
  kind: "embed" | "mp4" | "hls";
  url: string;
  quality?: string;
  language?: string;
};

type PlaybackResponse = {
  status: "success" | "not_configured";
  title: string;
  titleId: string;
  type: "movie" | "series";
  sources: PlaybackSource[];
  message?: string;
};

const image = (path: string) => `https://image.tmdb.org/t/p/w500${path}`;
const backdrop = (path: string) => `https://image.tmdb.org/t/p/w1280${path}`;

const catalog: Media[] = [
  {
    id: "arrival",
    title: "Arrival",
    year: "2016",
    genre: "Ficção científica",
    rating: "8.0",
    duration: "1h 56m",
    type: "movie",
    image: image("/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg"),
    backdrop: backdrop("/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg"),
    description: "Uma linguista é chamada para decifrar uma mensagem que pode mudar a relação da humanidade com o desconhecido.",
    accent: "#7c6dff",
    tag: "Escolha da casa",
  },
  {
    id: "dune",
    title: "Duna: Parte Dois",
    year: "2024",
    genre: "Aventura",
    rating: "8.6",
    duration: "2h 46m",
    type: "movie",
    image: image("/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg"),
    backdrop: backdrop("/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg"),
    description: "Paul Atreides se une a Chani e aos Fremen em uma jornada de vingança e destino.",
    accent: "#d28a54",
    tag: "Em alta",
  },
  {
    id: "oppenheimer",
    title: "Oppenheimer",
    year: "2023",
    genre: "Drama",
    rating: "8.1",
    duration: "3h 00m",
    type: "movie",
    image: image("/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg"),
    backdrop: backdrop("/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg"),
    description: "A história do cientista que liderou o projeto que inaugurou a era atômica.",
    accent: "#e35d4f",
    tag: "Premiado",
  },
  {
    id: "batman",
    title: "The Batman",
    year: "2022",
    genre: "Crime",
    rating: "7.8",
    duration: "2h 56m",
    type: "movie",
    image: image("/74xTEgt7R36Fpooo50r9T25onhq.jpg"),
    backdrop: backdrop("/74xTEgt7R36Fpooo50r9T25onhq.jpg"),
    description: "Em seu segundo ano de combate ao crime, Batman encara uma conspiração que atravessa Gotham.",
    accent: "#a8515a",
  },
  {
    id: "arcane",
    title: "Arcane",
    year: "2021",
    genre: "Animação",
    rating: "8.7",
    duration: "2 temporadas",
    type: "series",
    image: image("/fqldf2t8ztc9aiwn3k6mlX3tvRT.jpg"),
    backdrop: backdrop("/fqldf2t8ztc9aiwn3k6mlX3tvRT.jpg"),
    description: "Duas irmãs lutam em lados opostos de uma guerra entre cidades que não conseguem coexistir.",
    accent: "#9b6cff",
    tag: "Série do momento",
  },
  {
    id: "severance",
    title: "Ruptura",
    year: "2022",
    genre: "Mistério",
    rating: "8.7",
    duration: "2 temporadas",
    type: "series",
    image: image("/lSAn9aA6VvV1e5nqkU3e8f3b6oT.jpg"),
    backdrop: backdrop("/lSAn9aA6VvV1e5nqkU3e8f3b6oT.jpg"),
    description: "Funcionários de uma empresa passam por um procedimento que separa suas memórias do trabalho e da vida.",
    accent: "#4f9bd7",
  },
  {
    id: "fallout",
    title: "Fallout",
    year: "2024",
    genre: "Aventura",
    rating: "8.3",
    duration: "1 temporada",
    type: "series",
    image: image("/AnsSKR8K9A7K0WjS2oXjgYv0Tn.jpg"),
    backdrop: backdrop("/AnsSKR8K9A7K0WjS2oXjgYv0Tn.jpg"),
    description: "Uma sobrevivente deixa seu abrigo e descobre que o mundo lá fora é muito mais estranho do que imaginava.",
    accent: "#d3a65e",
  },
  {
    id: "spacex",
    title: "Órbita ao vivo",
    year: "Ao vivo",
    genre: "Ciência",
    rating: "LIVE",
    duration: "Agora",
    type: "live",
    image: image("/7W0G3Y7WfH3j9z0p2eN5r9Q6oQk.jpg"),
    backdrop: backdrop("/7W0G3Y7WfH3j9z0p2eN5r9Q6oQk.jpg"),
    description: "Imagens ao vivo do céu noturno, missões espaciais e conversas sobre o universo.",
    accent: "#5a89ff",
    tag: "Ao vivo",
  },
  {
    id: "racing",
    title: "Circuito mundial",
    year: "Ao vivo",
    genre: "Esportes",
    rating: "LIVE",
    duration: "Agora",
    type: "live",
    image: image("/2g85Y0B9nW5xqk2q6l8JrYd3T5p.jpg"),
    backdrop: backdrop("/2g85Y0B9nW5xqk2q6l8JrYd3T5p.jpg"),
    description: "Velocidade, estratégia e as principais histórias do automobilismo internacional.",
    accent: "#e95b62",
    tag: "Esportes",
  },
];

const navItems = [
  { label: "Início", path: "/", icon: HomeIcon },
  { label: "Filmes", path: "/movies", icon: Film },
  { label: "Séries", path: "/tv-shows", icon: MonitorPlay },
  { label: "TV ao vivo", path: "/live-tv", icon: Tv },
  { label: "Esportes", path: "/sports", icon: Zap },
  { label: "Jogos", path: "/games", icon: Gamepad2 },
];

const utilityItems = [
  { label: "Minha lista", path: "/my-list", icon: List },
  { label: "Torrent", path: "/torrent", icon: Compass },
];

function Logo() {
  return (
    <div className="brand-mark" aria-label="Flex Media Platform">
      <span className="brand-symbol" aria-hidden="true">F</span>
      <span className="brand-word">FLEX</span>
    </div>
  );
}

function MediaImage({ item, className = "" }: { item: Media; className?: string }) {
  return (
    <img
      className={className}
      src={item.image}
      alt={`Capa de ${item.title}`}
      loading="lazy"
      onError={(event) => {
        event.currentTarget.style.opacity = "0";
      }}
    />
  );
}

function Sidebar({ currentPath, onNavigate }: { currentPath: string; onNavigate: (path: string) => void }) {
  return (
    <aside className="sidebar">
      <Logo />
      <div className="sidebar-scroll">
        <div className="nav-group">
          <span className="nav-heading">Descobrir</span>
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = currentPath === item.path;
            return (
              <button className={`nav-item ${active ? "active" : ""}`} key={item.path} onClick={() => onNavigate(item.path)}>
                <Icon size={18} strokeWidth={active ? 2.3 : 1.8} />
                <span>{item.label}</span>
                {item.label === "TV ao vivo" && <span className="live-dot" />}
              </button>
            );
          })}
        </div>
        <div className="nav-group nav-group-secondary">
          <span className="nav-heading">Sua biblioteca</span>
          {utilityItems.map((item) => {
            const Icon = item.icon;
            const active = currentPath === item.path;
            return (
              <button className={`nav-item ${active ? "active" : ""}`} key={item.path} onClick={() => onNavigate(item.path)}>
                <Icon size={18} strokeWidth={active ? 2.3 : 1.8} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="sidebar-footer">
        <button className="profile-chip" onClick={() => onNavigate("/profile")} aria-label="Abrir perfil">
          <span className="profile-avatar">M</span>
          <span className="profile-copy"><strong>Visitante</strong><small>Conta de teste</small></span>
          <ChevronDown size={15} />
        </button>
        <button className="sidebar-settings" aria-label="Abrir configurações"><Settings2 size={16} /><span>Preferências</span></button>
      </div>
    </aside>
  );
}

function MobileNav({ currentPath, onNavigate }: { currentPath: string; onNavigate: (path: string) => void }) {
  const items = navItems.slice(0, 4);
  return (
    <nav className="mobile-nav" aria-label="Navegação mobile">
      {items.map((item) => {
        const Icon = item.icon;
        return <button key={item.path} className={currentPath === item.path ? "active" : ""} onClick={() => onNavigate(item.path)}><Icon size={18} /><span>{item.label === "Início" ? "Início" : item.label.split(" ")[0]}</span></button>;
      })}
      <button onClick={() => onNavigate("/search")} className={currentPath === "/search" ? "active" : ""}><Search size={18} /><span>Buscar</span></button>
    </nav>
  );
}

function TopBar({ query, setQuery, onSearch, onMenu }: { query: string; setQuery: (value: string) => void; onSearch: () => void; onMenu: () => void }) {
  return (
    <header className="topbar">
      <button className="mobile-menu" onClick={onMenu} aria-label="Abrir menu"><Menu size={21} /></button>
      <div className="search-box">
        <Search size={17} />
        <input value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && onSearch()} placeholder="Buscar filmes, séries, jogos..." aria-label="Buscar no catálogo" />
        {query && <button className="clear-search" onClick={() => setQuery("")} aria-label="Limpar busca"><X size={14} /></button>}
      </div>
      <div className="topbar-actions">
        <button className="icon-button" aria-label="Mensagens"><MessageCircle size={18} /></button>
        <button className="icon-button" aria-label="Abrir menu"><Settings2 size={18} /></button>
        <button className="user-button" aria-label="Abrir perfil"><span className="profile-avatar small">M</span><ChevronDown size={14} /></button>
      </div>
    </header>
  );
}

function Hero({ item, onPlay, onInfo, onAdd }: { item: Media; onPlay: () => void; onInfo: () => void; onAdd: () => void }) {
  return (
    <section className="hero" style={{ "--hero-image": `url(${item.backdrop})`, "--hero-accent": item.accent } as React.CSSProperties}>
      <div className="hero-art" />
      <div className="hero-content">
        <div className="eyebrow"><span className="eyebrow-line" /> EM DESTAQUE <span className="eyebrow-dot" /> FLEX ORIGINALS</div>
        <h1>{item.title}</h1>
        <p className="hero-meta"><span className="match">98% compatível</span><span>{item.year}</span><span>{item.duration}</span><span className="quality">4K</span></p>
        <p className="hero-description">{item.description}</p>
        <div className="hero-actions">
          <button className="button button-primary" onClick={onPlay}><Play size={17} fill="currentColor" /> Assistir agora</button>
          <button className="button button-ghost" onClick={onInfo}><span className="info-icon">i</span> Mais detalhes</button>
          <button className="round-button" onClick={onAdd} aria-label="Adicionar à minha lista"><Plus size={19} /></button>
        </div>
      </div>
      <div className="hero-pagination"><span className="pagination-number">01</span><span className="pagination-rule" /><span>04</span><button aria-label="Próximo destaque"><ChevronRight size={17} /></button></div>
    </section>
  );
}

function SectionHeader({ title, kicker, onPrev, onNext, action }: { title: string; kicker?: string; onPrev?: () => void; onNext?: () => void; action?: string }) {
  return (
    <div className="section-header">
      <div><span className="section-kicker">{kicker ?? "FLEX PICKS"}</span><h2>{title}</h2></div>
      <div className="section-tools">
        {action && <button className="text-button">{action} <ChevronRight size={14} /></button>}
        {onPrev && <button className="carousel-button" onClick={onPrev} aria-label="Anterior"><ChevronLeft size={17} /></button>}
        {onNext && <button className="carousel-button" onClick={onNext} aria-label="Próximo"><ChevronRight size={17} /></button>}
      </div>
    </div>
  );
}

function MediaCard({ item, onSelect, compact = false }: { item: Media; onSelect: () => void; compact?: boolean }) {
  return (
    <button className={`media-card ${compact ? "compact" : ""}`} onClick={onSelect} aria-label={`Abrir ${item.title}`}>
      <div className="media-poster" style={{ "--card-accent": item.accent } as React.CSSProperties}>
        <MediaImage item={item} />
        <div className="poster-shade" />
        {item.tag && <span className="poster-tag">{item.tag}</span>}
        <span className="poster-play"><Play size={15} fill="currentColor" /></span>
        {item.type === "live" && <span className="poster-live"><span className="live-dot" /> AO VIVO</span>}
        <span className="poster-rating"><Star size={11} fill="currentColor" /> {item.rating}</span>
      </div>
      <div className="card-copy"><strong>{item.title}</strong><span>{item.year} <i /> {item.genre}</span></div>
    </button>
  );
}

function MediaRow({ title, kicker, items, onSelect, action }: { title: string; kicker?: string; items: Media[]; onSelect: (item: Media) => void; action?: string }) {
  const [offset, setOffset] = useState(0);
  const visible = items.slice(offset, offset + 5);
  return (
    <section className="media-section">
      <SectionHeader title={title} kicker={kicker} action={action} onPrev={offset > 0 ? () => setOffset(Math.max(0, offset - 1)) : undefined} onNext={offset + 5 < items.length ? () => setOffset(Math.min(items.length - 5, offset + 1)) : undefined} />
      <div className="media-row">{visible.map((item) => <MediaCard key={item.id} item={item} onSelect={() => onSelect(item)} />)}</div>
    </section>
  );
}

function HomeView({ onSelect, onPlay, onAdd }: { onSelect: (item: Media) => void; onPlay: (item: Media) => void; onAdd: (item: Media) => void }) {
  const [heroIndex, setHeroIndex] = useState(0);
  const heroItems = catalog.slice(0, 4);
  const hero = heroItems[heroIndex];
  const movieItems = catalog.filter((item) => item.type === "movie");
  const seriesItems = catalog.filter((item) => item.type === "series");
  const liveItems = catalog.filter((item) => item.type === "live");
  return (
    <>
      <Hero item={hero} onPlay={() => onPlay(hero)} onInfo={() => onSelect(hero)} onAdd={() => onAdd(hero)} />
      <div className="home-body">
        <div className="continue-card"><div className="continue-thumb"><MediaImage item={catalog[4]} /><span><Play size={13} fill="currentColor" /></span></div><div className="continue-copy"><span className="section-kicker">CONTINUE ASSISTINDO</span><strong>{catalog[4].title}</strong><small>Temporada 1 · Episódio 4</small><div className="progress"><span style={{ width: "64%" }} /></div></div><button className="continue-button" onClick={() => onPlay(catalog[4])}><Play size={15} fill="currentColor" /> Continuar</button></div>
        <MediaRow title="Escolhidos para você" kicker="RECOMENDAÇÕES" items={movieItems} onSelect={onSelect} action="Ver catálogo" />
        <MediaRow title="Séries que estão em alta" kicker="AGORA NO FLEX" items={seriesItems} onSelect={onSelect} action="Ver tudo" />
        <MediaRow title="Canais ao vivo" kicker="NÃO PERCA" items={liveItems} onSelect={onSelect} />
      </div>
    </>
  );
}

function CatalogView({ kind, onSelect }: { kind: "movie" | "series" | "live" | "game"; onSelect: (item: Media) => void }) {
  const [genre, setGenre] = useState("Todos");
  const [sort, setSort] = useState("Relevantes");
  const kindItems = catalog.filter((item) => kind === "game" ? item.type === "movie" : item.type === kind);
  const genres = ["Todos", ...Array.from(new Set(kindItems.map((item) => item.genre)))];
  const items = kindItems.filter((item) => genre === "Todos" || item.genre === genre);
  const title = kind === "movie" ? "Filmes" : kind === "series" ? "Séries" : kind === "live" ? "TV ao vivo" : "Jogos";
  return <div className="catalog-view"><div className="page-intro"><div><span className="section-kicker">CATÁLOGO FLEX</span><h1>{title}</h1><p>Descubra histórias para assistir no seu ritmo.</p></div><button className="button button-ghost compact-button"><Sparkles size={15} /> Sugestões para mim</button></div><div className="filter-bar"><div className="filter-scroll">{genres.map((item) => <button key={item} className={`filter-chip ${genre === item ? "active" : ""}`} onClick={() => setGenre(item)}>{item}</button>)}</div><label className="sort-select"><span>Ordenar</span><select value={sort} onChange={(event) => setSort(event.target.value)}><option>Relevantes</option><option>Mais recentes</option><option>Melhor avaliados</option></select><ChevronDown size={14} /></label></div>{items.length ? <div className="catalog-grid">{items.map((item) => <MediaCard key={item.id} item={item} onSelect={() => onSelect(item)} />)}</div> : <EmptyState title="Nada por aqui ainda" copy="Tente outro filtro para continuar explorando." />}</div>;
}

function SearchView({ query, onSelect }: { query: string; onSelect: (item: Media) => void }) {
  const results = catalog.filter((item) => `${item.title} ${item.genre}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="catalog-view search-view"><div className="page-intro"><div><span className="section-kicker">BUSCA</span><h1>{query ? `Resultados para “${query}”` : "O que você quer assistir?"}</h1><p>{query ? `${results.length} títulos encontrados no catálogo.` : "Pesquise por título, gênero, artista ou palavra-chave."}</p></div></div>{query ? (results.length ? <div className="catalog-grid">{results.map((item) => <MediaCard key={item.id} item={item} onSelect={() => onSelect(item)} />)}</div> : <EmptyState title="Nenhum resultado" copy="Tente uma busca diferente ou explore nossas recomendações." />) : <div className="search-empty"><Search size={28} /><strong>Comece digitando na barra acima</strong><span>Seu próximo favorito pode estar a uma palavra de distância.</span></div>}</div>;
}

function ListView({ onSelect }: { onSelect: (item: Media) => void }) {
  return <div className="catalog-view"><div className="page-intro"><div><span className="section-kicker">SUA BIBLIOTECA</span><h1>Minha lista</h1><p>Seus títulos salvos, prontos para a próxima sessão.</p></div></div><div className="catalog-grid">{catalog.slice(1, 5).map((item) => <MediaCard key={item.id} item={item} onSelect={() => onSelect(item)} />)}</div></div>;
}

function EmptyState({ title, copy }: { title: string; copy: string }) {
  return <div className="empty-state"><div className="empty-icon"><Compass size={22} /></div><strong>{title}</strong><span>{copy}</span></div>;
}

function AuthorizedPlayback({ titleId }: { titleId: string }) {
  const [data, setData] = useState<PlaybackResponse | null>(null);
  const [selectedSource, setSelectedSource] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/titles/${encodeURIComponent(titleId)}/playback`)
      .then(async response => {
        if (!response.ok) throw new Error("Playback indisponível");
        return (await response.json()) as PlaybackResponse;
      })
      .then(result => {
        if (!cancelled) {
          setData(result);
          setSelectedSource(0);
        }
      })
      .catch(() => {
        if (!cancelled) setData(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [titleId]);

  if (loading || !data?.sources.length) return null;
  const source = data.sources[selectedSource] || data.sources[0];

  return <div className="authorized-playback">
    {source.kind === "embed" ? <iframe title={`Player autorizado de ${data.title}`} src={source.url} allow="autoplay; fullscreen; picture-in-picture; encrypted-media" sandbox="allow-scripts allow-same-origin allow-forms allow-presentation" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> : <video src={source.url} controls playsInline />}
    {data.sources.length > 1 && <div className="source-picker"><span>Fonte autorizada</span>{data.sources.map((candidate, index) => <button key={candidate.id} className={index === selectedSource ? "active" : ""} onClick={() => setSelectedSource(index)}>{candidate.name} · {candidate.quality}</button>)}</div>}
  </div>;
}

function PlayerView({ item, onBack }: { item: Media; onBack: () => void }) {
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [progress, setProgress] = useState(28);
  return <div className="player-view"><div className="player-top"><button className="back-button" onClick={onBack}><ArrowLeft size={18} /> Voltar</button><span className="player-brand"><span className="brand-symbol">F</span> FLEX PLAYER</span><button className="icon-button" aria-label="Mais opções"><Settings2 size={18} /></button></div><div className="player-frame" style={{ "--player-image": `url(${item.backdrop})`, "--player-accent": item.accent } as React.CSSProperties}><AuthorizedPlayback titleId={item.id} /><div className="player-backdrop" /><div className="player-center"><button className="player-play" onClick={() => setPlaying(!playing)} aria-label={playing ? "Pausar" : "Reproduzir"}>{playing ? <Pause size={26} fill="currentColor" /> : <Play size={26} fill="currentColor" />}</button><span>{playing ? "Reproduzindo demonstração" : "Pronto para assistir"}</span></div><div className="player-controls"><div className="player-progress"><span style={{ width: `${progress}%` }} /><input type="range" min="0" max="100" value={progress} onChange={(event) => setProgress(Number(event.target.value))} aria-label="Progresso do vídeo" /></div><div className="player-control-row"><button onClick={() => setPlaying(!playing)} aria-label={playing ? "Pausar" : "Reproduzir"}>{playing ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}</button><button onClick={() => setMuted(!muted)} aria-label={muted ? "Ativar som" : "Silenciar"}>{muted ? <VolumeX size={17} /> : <Volume2 size={17} />}</button><span className="player-time">{progress > 0 ? "00:32" : "00:00"} <i>/</i> {item.duration}</span><span className="player-spacer" /><button aria-label="Reiniciar"><RotateCcw size={17} /></button><button aria-label="Tela cheia"><Maximize2 size={17} /></button></div></div></div><div className="player-info"><div><span className="section-kicker">AGORA ASSISTINDO</span><h1>{item.title}</h1><p>{item.description}</p></div><div className="episode-select"><span>Temporada 1</span><ChevronDown size={15} /></div></div></div>;
}

function DetailModal({ item, onClose, onPlay, onAdd, inList }: { item: Media; onClose: () => void; onPlay: () => void; onAdd: () => void; inList: boolean }) {
  return <div className="modal-backdrop" role="presentation" onClick={onClose}><div className="detail-modal" role="dialog" aria-modal="true" aria-label={`Detalhes de ${item.title}`} onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={onClose} aria-label="Fechar detalhes"><X size={19} /></button><div className="detail-art" style={{ "--detail-image": `url(${item.backdrop})`, "--detail-accent": item.accent } as React.CSSProperties}><div /></div><div className="detail-body"><span className="section-kicker">{item.type === "live" ? "AO VIVO AGORA" : "DETALHES DO TÍTULO"}</span><h2>{item.title}</h2><p className="detail-meta"><span className="match">{item.rating === "LIVE" ? "LIVE" : `${item.rating} avaliação`}</span><span>{item.year}</span><span>{item.duration}</span><span>{item.genre}</span></p><p className="detail-description">{item.description}</p><div className="detail-actions"><button className="button button-primary" onClick={onPlay}><CirclePlay size={17} /> Assistir</button><button className={`button button-ghost ${inList ? "saved" : ""}`} onClick={onAdd}>{inList ? <Check size={16} /> : <Plus size={16} />} {inList ? "Na minha lista" : "Minha lista"}</button></div></div></div></div>;
}

function EmbedView({ src }: { src: string | null }) {
  const [blocked, setBlocked] = useState(false);
  return <div className="embed-view"><div className="page-intro"><div><span className="section-kicker">PLAYER INCORPORADO</span><h1>Conteúdo autorizado</h1><p>A página de reprodução é carregada dentro do Flex Media, sem extrair a fonte original.</p></div><span className="embed-origin">{src ? "Origem permitida: www.1flex.org" : "Aguardando URL"}</span></div>{src ? <div className="embed-frame-wrap"><iframe title="Player incorporado" src={src} allow="autoplay; fullscreen; picture-in-picture; encrypted-media" sandbox="allow-scripts allow-same-origin allow-forms allow-presentation" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" onLoad={() => setBlocked(false)} onError={() => setBlocked(true)} /><div className="embed-footer"><span><span className="live-dot" /> Página externa incorporada</span><a href={src} target="_blank" rel="noreferrer">Abrir em nova aba <ChevronRight size={14} /></a></div>{blocked && <div className="embed-notice"><strong>O site não permitiu a incorporação.</strong><span>Isso é controlado pelos cabeçalhos de segurança da página original. Use o botão acima para abrir em uma nova aba.</span></div>}</div> : <EmptyState title="Nenhum player selecionado" copy="Use /embed?src=URL para incorporar uma página autorizada do player." />}</div>;
}

export default function Home() {
  const [location, navigate] = useLocation();
  const [query, setQuery] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selected, setSelected] = useState<Media | null>(null);
  const [playerItem, setPlayerItem] = useState<Media | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [list, setList] = useState<string[]>(["batman"]);

  useEffect(() => {
    if (location.startsWith("/play/")) {
      const id = location.split("/").pop();
      const found = catalog.find((item) => item.id === id);
      if (found) {
        setPlayerItem(found);
        return;
      }
      if (!id) return;
      fetch(`/api/titles/${encodeURIComponent(id)}`)
        .then(async response => {
          if (!response.ok) throw new Error("Título não encontrado");
          return await response.json() as { id: string; title: string; type: "movie" | "series"; year?: string; description?: string };
        })
        .then(remote => setPlayerItem({
          id: remote.id,
          title: remote.title,
          year: remote.year || "",
          genre: "Conteúdo autorizado",
          rating: "—",
          duration: "",
          type: remote.type,
          image: image("/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg"),
          backdrop: backdrop("/x2FJsf1ElAgr63Y3PNPtJrcmpoe.jpg"),
          description: remote.description || "Conteúdo autorizado registrado no catálogo.",
          accent: "#9b6cff",
        }))
        .catch(() => setPlayerItem(null));
    } else {
      setPlayerItem(null);
    }
  }, [location]);

  const currentPath = location === "/" ? "/" : location.split("?")[0];
  const embeddedUrl = useMemo(() => {
    if (currentPath !== "/embed") return null;
    try {
      const raw = new URLSearchParams(window.location.search).get("src");
      if (!raw) return null;
      const parsed = new URL(raw, window.location.origin);
      return parsed.origin === "https://www.1flex.org" ? parsed.toString() : null;
    } catch {
      return null;
    }
  }, [currentPath, location]);
  const handleNavigate = (path: string) => { setMenuOpen(false); navigate(path); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const handleSearch = () => { setSearchQuery(query.trim()); handleNavigate("/search"); };
  const toggleList = (item: Media) => setList((current) => current.includes(item.id) ? current.filter((id) => id !== item.id) : [...current, item.id]);
  const page = useMemo(() => {
    if (currentPath === "/movies") return <CatalogView kind="movie" onSelect={setSelected} />;
    if (currentPath === "/tv-shows") return <CatalogView kind="series" onSelect={setSelected} />;
    if (currentPath === "/games") return <CatalogView kind="game" onSelect={setSelected} />;
    if (currentPath === "/live-tv" || currentPath === "/sports") return <CatalogView kind="live" onSelect={setSelected} />;
    if (currentPath === "/search") return <SearchView query={searchQuery} onSelect={setSelected} />;
    if (currentPath === "/my-list") return <ListView onSelect={setSelected} />;
    if (currentPath === "/torrent") return <div className="catalog-view"><div className="page-intro"><div><span className="section-kicker">ÁREA DE CONTEÚDO</span><h1>Torrent</h1><p>Esta área está pronta para conectar uma fonte autorizada.</p></div></div><EmptyState title="Nenhuma fonte conectada" copy="Configure uma integração permitida para visualizar seus arquivos." /></div>;
    if (currentPath === "/embed") return <EmbedView src={embeddedUrl} />;
    return <HomeView onSelect={setSelected} onPlay={(item) => handleNavigate(`/play/${item.id}`)} onAdd={toggleList} />;
  }, [currentPath, searchQuery, embeddedUrl]);

  if (playerItem) return <PlayerView item={playerItem} onBack={() => handleNavigate("/")} />;
  return <div className="app-shell"><Sidebar currentPath={currentPath} onNavigate={handleNavigate} /><div className="main-shell"><TopBar query={query} setQuery={setQuery} onSearch={handleSearch} onMenu={() => setMenuOpen(!menuOpen)} />{menuOpen && <div className="mobile-drawer"><Logo />{[...navItems, ...utilityItems].map((item) => { const Icon = item.icon; return <button key={item.path} onClick={() => handleNavigate(item.path)}><Icon size={18} />{item.label}</button>; })}</div>}<main className="main-content">{page}</main><MobileNav currentPath={currentPath} onNavigate={handleNavigate} /></div>{selected && <DetailModal item={selected} onClose={() => setSelected(null)} onPlay={() => { setSelected(null); handleNavigate(`/play/${selected.id}`); }} onAdd={() => toggleList(selected)} inList={list.includes(selected.id)} />}</div>;
}
