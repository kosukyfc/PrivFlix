import { URL } from "node:url";

export type MediaType = "movie" | "series";
export type PlaybackKind = "embed" | "mp4" | "hls";

export type PlaybackSource = {
  id: string;
  name: string;
  kind: PlaybackKind;
  url: string;
  quality?: string;
  language?: string;
};

export type CatalogTitle = {
  id: string;
  title: string;
  type: MediaType;
  year?: string;
  description?: string;
  sources: PlaybackSource[];
};

const configuredOrigins = () =>
  (process.env.MEDIA_ALLOWED_ORIGINS || "https://www.1flex.org")
    .split(",")
    .map(origin => origin.trim())
    .filter(Boolean);

function allowedSourceUrl(value: string | undefined): string | null {
  if (!value) return null;

  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:") return null;
    if (!configuredOrigins().includes(parsed.origin)) return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

function envSource(titleId: string, suffix: string): string | null {
  return allowedSourceUrl(process.env[`MEDIA_${suffix}_${titleId}`]);
}

function sourcesFor(titleId: string): PlaybackSource[] {
  const sources: PlaybackSource[] = [];
  const embed = envSource(titleId, "PLAYER_URL");
  const mp4 = envSource(titleId, "MP4_URL");
  const hls = envSource(titleId, "HLS_URL");

  if (embed) {
    sources.push({
      id: `${titleId}-embed`,
      name: "Player autorizado",
      kind: "embed",
      url: embed,
      quality: process.env[`MEDIA_PLAYER_QUALITY_${titleId}`] || "Original",
      language: process.env[`MEDIA_PLAYER_LANGUAGE_${titleId}`] || "pt-BR",
    });
  }
  if (mp4) {
    sources.push({
      id: `${titleId}-mp4`,
      name: "Arquivo MP4 autorizado",
      kind: "mp4",
      url: mp4,
      quality: process.env[`MEDIA_MP4_QUALITY_${titleId}`] || "1080p",
      language: process.env[`MEDIA_MP4_LANGUAGE_${titleId}`] || "pt-BR",
    });
  }
  if (hls) {
    sources.push({
      id: `${titleId}-hls`,
      name: "Stream HLS autorizado",
      kind: "hls",
      url: hls,
      quality: process.env[`MEDIA_HLS_QUALITY_${titleId}`] || "Adaptive",
      language: process.env[`MEDIA_HLS_LANGUAGE_${titleId}`] || "pt-BR",
    });
  }

  return sources;
}

const titleDefinitions: Omit<CatalogTitle, "sources">[] = [
  {
    id: "969681",
    title: process.env.MEDIA_TITLE_969681 || "Título autorizado 969681",
    type: "movie",
    year: process.env.MEDIA_YEAR_969681 || "",
    description: "Título registrado para uma fonte licenciada configurada pelo administrador.",
  },
];

export function listCatalog(): CatalogTitle[] {
  return titleDefinitions.map(title => ({ ...title, sources: sourcesFor(title.id) }));
}

export function getTitle(titleId: string): CatalogTitle | null {
  const definition = titleDefinitions.find(title => title.id === titleId);
  return definition ? { ...definition, sources: sourcesFor(titleId) } : null;
}

export function getPlayback(titleId: string) {
  const title = getTitle(titleId);
  if (!title) return null;

  return {
    status: title.sources.length > 0 ? "success" : "not_configured",
    title: title.title,
    titleId: title.id,
    type: title.type,
    sources: title.sources,
    message:
      title.sources.length > 0
        ? undefined
        : "Nenhuma fonte autorizada foi configurada para este título.",
  };
}
