# TODO — Flex Media Platform

## Interface principal navegável
- [ ] A página inicial deve deixar de exibir o conteúdo de exemplo do starter e apresentar uma home de streaming visualmente completa.
- [ ] A home deve conter navegação para filmes, séries, jogos, TV ao vivo, esportes, busca, minha lista e torrent.
- [ ] O layout deve ser responsivo e oferecer navegação equivalente em desktop e mobile.

## Catálogo e descoberta
- [ ] As páginas de catálogo devem apresentar cards, trilhos horizontais, filtros de gênero e busca por texto.
- [ ] Cada card deve oferecer título, metadados, avaliação e ação de abrir detalhes.
- [ ] A busca deve atualizar o estado da interface e mostrar estado vazio quando não houver correspondências.

## Player e estados de interface
- [ ] A rota de reprodução deve exibir player demonstrativo, controles de play, volume, progresso, tela cheia e seleção de episódio quando aplicável.
- [x] A API própria deve expor `/api/catalog`, `/api/titles/:id` e `/api/titles/:id/playback` para títulos registrados localmente.
- [x] O playback deve aceitar somente fontes HTTPS autorizadas configuradas por ambiente nos modos embed, MP4 ou HLS; o frontend deve oferecer seleção quando houver mais de uma fonte.
- [ ] A interface deve conter estados de carregamento, feedback de ação e tratamento visual de conteúdo ausente.
- [ ] Não usar tokens, sessões, conteúdo protegido ou fontes de mídia não autorizadas.

## Qualidade do Preview
- [ ] O servidor deve continuar respondendo na porta configurada e `/api/health` deve permanecer saudável.
- [ ] `public/manus-routes.json` deve declarar todas as páginas e não incluir APIs ou assets.
- [ ] `pnpm check` e `pnpm build` devem concluir sem erro.
